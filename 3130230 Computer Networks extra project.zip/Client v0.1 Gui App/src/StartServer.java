
public class StartServer {
	public static void main(String args[]){
		Server.setUpServer(true);
	}
}

