import java.io.IOException;

public class StartClient {
	public static void main(String args[]) throws ClassNotFoundException, IOException{
		Client.Start();
	}
}
