
public class start {
	public static void main(String args[]) throws Exception {
		
		Main.mediaUrl = "http://192.168.1.83:7000/Steins1/out.m3u8";
		
		Main.main(args);
	}

}
