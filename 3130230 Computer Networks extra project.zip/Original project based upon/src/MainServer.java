import java.io.*;

public class MainServer {


	public static void main(String args[]) throws IOException{
		
		MainServerStuff main = new MainServerStuff();
		main.startRunning();
				
	}
}
